# screens.py
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import random
import sqlite3
import os
import hashlib
from datetime import datetime

from constants import *
from state import state
import state as app_state
from db import *
from ui_utils import *
import ui_utils


def random_walk(value, min_v, max_v, step=1):
    value += random.uniform(-step, step)
    return max(min_v, min(max_v, value))


def set_screen(nome):
    app_state.current_screen = nome


def show_dashboard():
    set_screen('Dashboard')
    clear_main()
    make_header('DASHBOARD', 'Visão geral da produção de Hidrogênio Verde')

    top = tk.Frame(ui_utils.main, bg=BG)
    top.pack(fill='x', padx=20)

    c1, prod_label = card(top, 'PRODUÇÃO ATUAL', '120,5 kg/h', 'H₂ produzido')
    c2, daily_label = card(top, 'PRODUÇÃO DIÁRIA', '2.892 kg', 'Meta: 3.500 kg', BLUE)
    c3, eff_label = card(top, 'EFICIÊNCIA ENERGÉTICA', '91%', 'Excelente')
    c4, energy_label = card(top, 'CONSUMO DE ENERGIA', '4,28 MWh', '-8% vs ontem')
    c5, emission_label = card(top, 'EMISSÃO EVITADA (CO₂)', '5,62 t', 'Hoje')
    for c in [c1, c2, c3, c4, c5]:
        c.pack(side='left', expand=True, fill='both', padx=4, pady=3)

    middle = tk.Frame(ui_utils.main, bg=BG)
    middle.pack(fill='both', expand=True, padx=20)

    graph_panel = panel(middle, 'PRODUÇÃO DE HIDROGÊNIO (kg)')
    graph_panel.pack(side='left', fill='both', expand=True, padx=4, pady=3)
    canvas = tk.Canvas(graph_panel, bg=CARD, highlightthickness=0, height=320)
    canvas.pack(fill='both', expand=True, padx=12, pady=9)

    right = tk.Frame(middle, bg=BG, width=430)
    right.pack(side='right', fill='y')
    matrix = panel(right, 'MATRIZ ENERGÉTICA')
    matrix.pack(fill='x', padx=4, pady=3)
    tk.Label(matrix, text="68% Renovável\n\n☀ Solar: 68%\n💨 Eólica: 22%\n🔋 Armazenamento: 10%",
             fg='white', bg=CARD, justify='left', font=(FONT, 16)).pack(anchor='w', padx=20, pady=20)

    eq = panel(right, 'STATUS DOS EQUIPAMENTOS')
    eq.pack(fill='x', padx=4, pady=3)
    eq_lista_container = tk.Frame(eq, bg=CARD, height=185)
    eq_lista_container.pack(fill='x', padx=10, pady=(0, 12))
    eq_lista_container.pack_propagate(False)
    eq_canvas = tk.Canvas(eq_lista_container, bg=CARD, highlightthickness=0)
    eq_scrollbar = tk.Scrollbar(eq_lista_container, orient='vertical', command=eq_canvas.yview)
    eq_scroll_frame = tk.Frame(eq_canvas, bg=CARD)
    eq_scroll_frame.bind('<Configure>', lambda e: eq_canvas.configure(scrollregion=eq_canvas.bbox('all')))
    eq_canvas.create_window((0, 0), window=eq_scroll_frame, anchor='nw')
    eq_canvas.configure(yscrollcommand=eq_scrollbar.set)
    eq_canvas.pack(side='left', fill='both', expand=True)
    eq_scrollbar.pack(side='right', fill='y')

    def rolar_equipamentos(event):
        eq_canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')

    eq_canvas.bind('<MouseWheel>', rolar_equipamentos)
    eq_scroll_frame.bind('<MouseWheel>', rolar_equipamentos)

    if state['equipment']:
        for item in state['equipment']:
            color = GREEN if item[1] == 'Operando' else YELLOW if item[1] in ['Atenção', 'Manutenção'] else RED
            linha = tk.Label(eq_scroll_frame, text=f'{item[0]:<28} ● {item[1]}', fg=color, bg=CARD2,
                             anchor='w', font=(FONT, 11), padx=10, pady=8)
            linha.pack(fill='x', padx=2, pady=3)
            animar_botao(linha, CARD2, CARD3)
            linha.bind('<MouseWheel>', rolar_equipamentos)
    else:
        tk.Label(eq_scroll_frame, text='Nenhum equipamento cadastrado.', fg=GRAY, bg=CARD,
                 anchor='w', font=(FONT, 11), padx=10, pady=8).pack(fill='x', padx=2, pady=3)

    bottom = tk.Frame(ui_utils.main, bg=BG)
    bottom.pack(fill='both', expand=True, padx=20)
    p = panel(bottom, 'PARÂMETROS EM TEMPO REAL')
    p.pack(side='left', fill='both', expand=True, padx=4, pady=3)

    # Área com scroll igual ao painel de Status dos Equipamentos.
    # Mantém altura fixa e permite rolar quando tiver muitos parâmetros.
    param_lista_container = tk.Frame(p, bg=CARD, height=230)
    param_lista_container.pack(fill='both', expand=True, padx=8, pady=8)
    param_lista_container.pack_propagate(False)

    param_canvas = tk.Canvas(param_lista_container, bg=CARD, highlightthickness=0)
    param_scrollbar = tk.Scrollbar(param_lista_container, orient='vertical', command=param_canvas.yview)
    scrollable_frame = tk.Frame(param_canvas, bg=CARD)

    scrollable_frame.bind(
        '<Configure>',
        lambda e: param_canvas.configure(scrollregion=param_canvas.bbox('all'))
    )

    param_canvas.create_window((0, 0), window=scrollable_frame, anchor='nw')
    param_canvas.configure(yscrollcommand=param_scrollbar.set)

    param_canvas.pack(side='left', fill='both', expand=True)
    param_scrollbar.pack(side='right', fill='y')

    def rolar_parametros(event):
        param_canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')

    param_canvas.bind('<MouseWheel>', rolar_parametros)
    scrollable_frame.bind('<MouseWheel>', rolar_parametros)

    param_labels = {}
    params = {'Temperatura': '43,2 °C', 'Pressão': '28,7 bar', 'Tensão': '732 V', 'Corrente': '215 A',
              'pH da Água': '6,8', 'Fluxo de Água': '124 L/min', 'Pureza do H₂': '99,7%',
              'Pressão do Tanque': '52 bar', 'Consumo Solar': '2,8 MWh', 'Consumo Eólico': '1,4 MWh',
              'Eficiência da Célula': '93%', 'Temperatura Ambiente': '29 °C'}
    for name, value in params.items():
        row = tk.Frame(scrollable_frame, bg=CARD2)
        row.pack(fill='x', padx=12, pady=5)
        aplicar_hover(row, CARD2, CARD3)
        row.bind('<MouseWheel>', rolar_parametros)

        nome_label = tk.Label(row, text=name, fg='white', bg=CARD2, font=(FONT, 11))
        nome_label.pack(side='left', padx=10, pady=8)
        nome_label.bind('<MouseWheel>', rolar_parametros)

        v = tk.Label(row, text=value, fg='white', bg=CARD2, font=(FONT, 11, 'bold'))
        v.pack(side='right', padx=10)
        v.bind('<MouseWheel>', rolar_parametros)
        param_labels[name] = v

    alerts_panel = panel(bottom, 'ALERTAS ATIVOS')
    alerts_panel.pack(side='left', fill='both', expand=True, padx=4, pady=3)
    for nivel, titulo, desc, hora in state['alerts']:
        color = RED if nivel in ['Alto', 'Crítico'] else YELLOW if nivel == 'Médio' else BLUE
        tk.Label(alerts_panel, text=f'{hora}  {titulo}\n{desc}', fg=color, bg=CARD,
                 justify='left', anchor='w', font=(FONT, 11)).pack(fill='x', padx=15, pady=8)

    lots = panel(bottom, 'ÚLTIMOS LOTES PRODUZIDOS')
    lots.pack(side='left', fill='both', expand=True, padx=4, pady=3)
    lots_box = tk.Text(lots, bg=CARD, fg='white', bd=0, font=('Cascadia Mono', 10))
    lots_box.pack(fill='both', expand=True, padx=10, pady=10)

    def draw_chart():
        canvas.delete('all')
        w, h = canvas.winfo_width(), canvas.winfo_height()
        values = state['chart_values']
        if w < 100 or len(values) < 2:
            return
        for y in range(40, int(h), 55):
            canvas.create_line(15, y, w - 15, y, fill='#1e293b')
        max_v, min_v = max(values), min(values)
        points = []
        for i, val in enumerate(values):
            x = 18 + i * ((w - 36) / (len(values) - 1))
            y = h - 20 - ((val - min_v) / (max_v - min_v + 1)) * (h - 55)
            points.extend([x, y])
        area = points + [points[-2], h - 20, points[0], h - 20]
        canvas.create_polygon(area, fill='#0f2f2b', outline='')
        for i in range(0, len(points) - 2, 2):
            canvas.create_line(points[i], points[i+1], points[i+2], points[i+3], fill='#14532d', width=7, smooth=True)
            canvas.create_line(points[i], points[i+1], points[i+2], points[i+3], fill=GREEN, width=3, smooth=True)
        x, y = points[-2], points[-1]
        canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill=GREEN, outline='')

    def local_update():
        if app_state.current_screen != 'Dashboard':
            return
        state['production'] = random_walk(state['production'], 90, 145, 2)
        state['daily'] = random.randint(2400, 3500)
        state['efficiency'] = random_walk(state['efficiency'], 82, 99, 1)
        state['energy'] = random_walk(state['energy'], 3.5, 5.5, 0.08)
        state['emission'] = random_walk(state['emission'], 4, 8, 0.1)
        state['chart_values'].pop(0); state['chart_values'].append(random.randint(80, 155))
        prod_label.config(text=f"{state['production']:.1f} kg/h")
        daily_label.config(text=f"{state['daily']:,} kg".replace(',', '.'))
        eff_label.config(text=f"{state['efficiency']:.0f}%")
        energy_label.config(text=f"{state['energy']:.2f} MWh")
        emission_label.config(text=f"{state['emission']:.2f} t")

        temp_atual = random.uniform(38, 58); pressao_atual = random.uniform(24, 38)
        tensao_atual = random.randint(690, 780); corrente_atual = random.randint(190, 260); ph_atual = random.uniform(5.6, 8.2)
        param_labels['Temperatura'].config(text=f'{temp_atual:.1f} °C')
        param_labels['Pressão'].config(text=f'{pressao_atual:.1f} bar')
        param_labels['Tensão'].config(text=f'{tensao_atual} V')
        param_labels['Corrente'].config(text=f'{corrente_atual} A')
        param_labels['pH da Água'].config(text=f'{ph_atual:.1f}')

        try:
            limite_temp = float(state['settings'].get('limite_temp', '50 °C').replace('°C', '').replace('°', '').replace('C', '').strip())
        except ValueError:
            limite_temp = 50
        if temp_atual >= limite_temp:
            gerar_alerta_automatico('Alto', 'Temperatura perigosa', f'Temperatura atingiu {temp_atual:.1f} °C, acima do limite de {limite_temp:.0f} °C.')
        if pressao_atual >= 35:
            gerar_alerta_automatico('Alto', 'Pressão perigosa', f'Pressão atingiu {pressao_atual:.1f} bar.')
        if ph_atual < 6.0 or ph_atual > 8.0:
            gerar_alerta_automatico('Médio', 'pH fora da faixa segura', f'pH da água medido em {ph_atual:.1f}.')

        lots_box.delete('1.0', tk.END)
        for i in range(6):
            lote = f'LOT-2025-0523-{random.randint(1000,9999)}'
            hora = f'23/05 {random.randint(0,23):02d}:{random.randint(0,59):02d}'
            qtd = f'{random.randint(110,125)} kg'
            lots_box.insert(tk.END, f'{lote:<24} {hora:<12} {qtd}\n')
        draw_chart()
        ui_utils.root.after(3000, local_update)
    local_update()


def show_producao():
    set_screen('Produção'); clear_main(); make_header('PRODUÇÃO', 'Controle operacional da eletrólise e geração de hidrogênio')
    top = tk.Frame(ui_utils.main, bg=BG); top.pack(fill='x', padx=20)
    for title, value, sub in [('Modo de produção', state['settings']['modo_operacao'], 'Controle operacional'), ('Meta diária', state['settings']['meta_diaria'], 'Configurável'), ('Produção média', '118 kg/h', 'Últimas 24h'), ('Pureza do H₂', '99,7%', 'Padrão industrial')]:
        c, _ = card(top, title, value, sub); c.pack(side='left', expand=True, fill='both', padx=4, pady=3)
    body = panel(ui_utils.main, 'ORDENS DE PRODUÇÃO SIMULADAS'); body.pack(fill='x', padx=20, pady=6)
    rows = [[f'OP-{20250523}-{100+i}', random.choice(['Em execução', 'Finalizada', 'Aguardando']), f'{random.randint(800,1300)} kg', f'{random.randint(88,99)}%'] for i in range(10)]
    table(body, ['Ordem', 'Status', 'Volume previsto', 'Eficiência'], rows)


def show_energia():
    set_screen('Energia'); clear_main(); make_header('ENERGIA', 'Monitoramento da matriz energética e consumo')
    top = tk.Frame(ui_utils.main, bg=BG); top.pack(fill='x', padx=20)
    for title, value, sub, color in [('Solar', '68%', 'Fonte predominante', YELLOW), ('Eólica', '22%', 'Complementar', BLUE), ('Armazenamento', '10%', 'Baterias', GREEN), ('Consumo atual', f"{state['energy']:.2f} MWh", 'Atualizado', GREEN)]:
        c, _ = card(top, title, value, sub, color); c.pack(side='left', expand=True, fill='both', padx=4, pady=3)
    body = panel(ui_utils.main, 'DISTRIBUIÇÃO HORÁRIA DE ENERGIA'); body.pack(fill='x', padx=20, pady=6)
    rows = [[f'{h:02d}:00', f'{random.uniform(2.5,5.8):.2f} MWh', f'{random.randint(55,75)}%', f'{random.randint(15,30)}%', f'{random.randint(5,15)}%'] for h in range(0, 24, 2)]
    table(body, ['Horário', 'Consumo', 'Solar', 'Eólica', 'Bateria'], rows)




def extrair_numero(valor, padrao=0):
    texto = str(valor)
    numeros = ''.join(ch for ch in texto if ch.isdigit() or ch == '.')
    try:
        return float(numeros) if numeros else padrao
    except ValueError:
        return padrao


def calcular_risco_equipamento(item):
    nome, status, carga, temperatura, observacao = item
    carga_num = extrair_numero(carga, 100)
    temp_num = extrair_numero(temperatura, 25)
    pontos = 0
    motivos = []
    if status in ['Atenção', 'Manutenção', 'Offline']:
        pontos += 35
        motivos.append(f'status {status}')
    if temp_num >= 50:
        pontos += 35
        motivos.append(f'temperatura alta ({temperatura})')
    elif temp_num >= 45:
        pontos += 18
        motivos.append(f'temperatura em atenção ({temperatura})')
    if carga_num < 70:
        pontos += 25
        motivos.append(f'carga baixa ({carga})')
    elif carga_num > 95:
        pontos += 12
        motivos.append(f'carga muito alta ({carga})')
    pontos = min(99, pontos)
    if pontos >= 70:
        nivel = 'Alto'
    elif pontos >= 35:
        nivel = 'Médio'
    else:
        nivel = 'Baixo'
    return pontos, nivel, ', '.join(motivos) if motivos else 'parâmetros dentro da faixa normal'


def assinatura_demo(certificado, lote):
    base = f'{certificado}|{lote}|H2V-TRACE'
    return hashlib.sha256(base.encode('utf-8')).hexdigest()[:18].upper()


def exportar_texto_padrao(nome_arquivo, conteudo):
    caminho = filedialog.asksaveasfilename(defaultextension='.txt', initialfile=nome_arquivo, filetypes=[('Arquivo de texto', '*.txt')])
    if not caminho:
        return
    with open(caminho, 'w', encoding='utf-8') as arquivo:
        arquivo.write(conteudo)
    messagebox.showinfo('Arquivo gerado', f'Arquivo salvo em:\n{caminho}')


def abrir_qr_visual(titulo, conteudo):
    janela = tk.Toplevel(ui_utils.root)
    janela.title(titulo)
    janela.configure(bg=BG)
    janela.transient(ui_utils.root)
    janela.grab_set()
    abrir_popup_centralizado(janela, 460, 560)
    tk.Label(janela, text=titulo.upper(), fg=TEXT, bg=BG, font=(FONT_BOLD, 16, 'bold')).pack(pady=(16, 6))
    tk.Label(janela, text='QR Code demonstrativo para rastreabilidade', fg=GRAY, bg=BG, font=(FONT, 10)).pack(pady=(0, 8))
    canvas = tk.Canvas(janela, width=290, height=290, bg='white', highlightthickness=0)
    canvas.pack(pady=8)
    digest = hashlib.sha256(conteudo.encode('utf-8')).hexdigest()
    matriz = 21; tamanho = 12; margem = 18
    def marcador(x, y):
        canvas.create_rectangle(x, y, x + tamanho * 7, y + tamanho * 7, fill='black', outline='')
        canvas.create_rectangle(x + tamanho, y + tamanho, x + tamanho * 6, y + tamanho * 6, fill='white', outline='')
        canvas.create_rectangle(x + tamanho * 2, y + tamanho * 2, x + tamanho * 5, y + tamanho * 5, fill='black', outline='')
    marcador(margem, margem); marcador(margem + tamanho * 14, margem); marcador(margem, margem + tamanho * 14)
    bits = bin(int(digest, 16))[2:].zfill(256); idx = 0
    for linha in range(matriz):
        for coluna in range(matriz):
            em_marcador = (linha < 7 and coluna < 7) or (linha < 7 and coluna >= 14) or (linha >= 14 and coluna < 7)
            if em_marcador:
                continue
            if bits[idx % len(bits)] == '1':
                x = margem + coluna * tamanho; y = margem + linha * tamanho
                canvas.create_rectangle(x, y, x + tamanho, y + tamanho, fill='black', outline='')
            idx += 1
    texto = tk.Text(janela, bg=CARD, fg=TEXT, height=5, bd=0, font=(FONT, 10), wrap='word')
    texto.insert('1.0', conteudo); texto.config(state='disabled'); texto.pack(fill='x', padx=24, pady=10)
    tk.Button(janela, text='Fechar', bg=RED, fg='white', font=(FONT, 11, 'bold'), command=janela.destroy).pack(pady=8, ipadx=18, ipady=5)

def show_equipamentos():
    set_screen('Equipamentos'); clear_main(); make_header('EQUIPAMENTOS', 'Controle de operação, manutenção e sensores')
    body = panel(ui_utils.main, 'EQUIPAMENTOS DA ESTAÇÃO'); body.pack(fill='x', padx=20, pady=6)
    tree = table(body, ['Equipamento', 'Status', 'Carga', 'Temperatura', 'Observação'], state['equipment'])

    def adicionar():
        agora = datetime.now().strftime('%d/%m/%Y')
        campos = [
            {'nome': 'nome', 'label': 'Nome do equipamento', 'valor': f'Equipamento {len(state["equipment"]) + 1:02d}'},
            {'nome': 'status', 'label': 'Status', 'opcoes': ['Operando', 'Atenção', 'Manutenção', 'Offline'], 'valor': 'Operando'},
            {'nome': 'carga', 'label': 'Carga', 'valor': f'{random.randint(70, 98)}%'},
            {'nome': 'temperatura', 'label': 'Temperatura', 'valor': f'{random.randint(28, 48)} °C'},
            {'nome': 'observacao', 'label': 'Observação', 'valor': f'Última revisão: {agora}'}]
        def salvar(dados):
            if not dados['nome']:
                messagebox.showwarning('Campo obrigatório', 'Digite o nome do equipamento.'); return
            salvar_equipamento_no_banco(dados['nome'], dados['status'], dados['carga'], dados['temperatura'], dados['observacao'])
            carregar_equipamentos(); show_equipamentos()
        criar_janela_cadastro('Adicionar equipamento', campos, salvar)

    def deletar():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum item selecionado', 'Selecione um equipamento para deletar.'); return
        valores = tree.item(selecionado[0], 'values')
        if messagebox.askyesno('Confirmar exclusão', f'Deseja deletar {valores[0]}?'):
            deletar_equipamento_do_banco(valores[0], valores[4]); carregar_equipamentos(); show_equipamentos()

    def alterar_status(novo_status):
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum item selecionado', 'Selecione um equipamento para alterar o status.'); return
        valores = tree.item(selecionado[0], 'values')
        atualizar_status_equipamento_no_banco(valores[0], valores[4], novo_status)
        if novo_status == 'Manutenção':
            gerar_alerta_automatico('Médio', f'{valores[0]} em manutenção', 'Equipamento definido manualmente como em manutenção.')
        carregar_equipamentos(); messagebox.showinfo('Status atualizado', f'{valores[0]} agora está como {novo_status}.'); show_equipamentos()

    def simular_falha():
        if not state['equipment']:
            messagebox.showwarning('Sem equipamentos', 'Adicione um equipamento antes de simular falha.'); return
        item = random.choice(state['equipment'])
        item[1] = 'Atenção'; item[2] = f'{random.randint(60,82)}%'; item[3] = f'{random.randint(48,58)} °C'
        gerar_alerta_automatico('Alto', f'Atenção em {item[0]}', 'Sensor detectou variação acima do normal.')
        conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()
        cursor.execute('UPDATE equipamentos SET status = ?, carga = ?, temperatura = ? WHERE id = (SELECT id FROM equipamentos WHERE nome = ? LIMIT 1)', (item[1], item[2], item[3], item[0]))
        conn.commit(); conn.close()
        carregar_equipamentos(); messagebox.showwarning('Alerta gerado', f'Foi detectada uma variação em {item[0]}.'); show_equipamentos()

    def analisar_ia_preditiva():
        if not state['equipment']:
            messagebox.showwarning('Sem equipamentos', 'Adicione equipamentos antes de usar a IA preditiva.'); return
        linhas = []
        for item in state['equipment']:
            risco, nivel, motivo = calcular_risco_equipamento(item)
            linhas.append(f'{item[0]}: risco {risco}% ({nivel}) - {motivo}')
            if nivel == 'Alto':
                gerar_alerta_automatico('Alto', f'IA preditiva: risco em {item[0]}', f'Risco estimado em {risco}%: {motivo}.')
        try:
            registrar_auditoria('IA preditiva', 'Análise de risco executada nos equipamentos')
        except Exception:
            pass
        carregar_alertas()
        messagebox.showinfo('IA preditiva - análise concluída', '\n'.join(linhas))

    btns = tk.Frame(ui_utils.main, bg=BG); btns.pack(pady=10)
    for text, bg, fg, cmd in [('Adicionar equipamento', BLUE, 'white', adicionar), ('Marcar como Operando', GREEN, 'black', lambda: alterar_status('Operando')), ('Marcar em Manutenção', YELLOW, 'black', lambda: alterar_status('Manutenção')), ('Deletar equipamento', RED, 'white', deletar), ('Simular falha', YELLOW, 'black', simular_falha), ('IA preditiva', PURPLE, 'white', analisar_ia_preditiva)]:
        tk.Button(btns, text=text, bg=bg, fg=fg, font=(FONT, 12, 'bold'), command=cmd).pack(side='left', padx=8)
    animar_botoes_do_frame(btns)


def show_lotes():
    set_screen('Lotes'); clear_main(); make_header('LOTES E RASTREABILIDADE', 'Rastreamento digital da produção e origem da energia')
    body = panel(ui_utils.main, 'LOTES PRODUZIDOS'); body.pack(fill='x', padx=20, pady=6)
    tree = table(body, ['Lote', 'Início', 'Quantidade', 'Origem energia', 'Certificado'], state['lotes'])

    def adicionar():
        codigo = f'LOT-{datetime.now().strftime("%Y%m%d")}-{random.randint(1000,9999)}'
        campos = [
            {'nome':'lote','label':'Código do lote','valor':codigo},
            {'nome':'quantidade','label':'Quantidade','valor':str(random.randint(100,140))},
            {'nome':'origem_energia','label':'Origem da energia','opcoes':['Solar','Eólica','Mista','Bateria'],'valor':'Mista'}]
        def salvar(dados):
            quantidade_num = ''.join(ch for ch in dados['quantidade'] if ch.isdigit())
            if not dados['lote']:
                messagebox.showwarning('Campo obrigatório','Digite o código do lote.'); return
            if not quantidade_num:
                messagebox.showwarning('Campo obrigatório','Digite a quantidade produzida.'); return
            inicio_automatico = datetime.now().strftime('%d/%m/%Y %H:%M')
            quantidade_final = f'{quantidade_num} kg'
            salvar_lote_no_banco(dados['lote'], inicio_automatico, quantidade_final, dados['origem_energia'], 'Pendente')
            carregar_lotes(); show_lotes()
        criar_janela_cadastro('Adicionar lote', campos, salvar)

    def adicionar_certificado_lote_selecionado():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum lote selecionado','Selecione um lote ainda não certificado.'); return
        valores = tree.item(selecionado[0], 'values')
        lote = valores[0]; status_certificado = valores[4]
        if status_certificado == 'Certificado' or any(cert[1] == lote for cert in state['certificados']):
            messagebox.showwarning('Lote já certificado','Esse lote já possui certificado e não pode receber outro.'); return
        abrir_formulario_certificado(lote_fixo=lote)

    btns = tk.Frame(ui_utils.main, bg=BG); btns.pack(pady=6)
    tk.Button(btns, text='Adicionar lote', bg=BLUE, fg='white', font=(FONT, 12, 'bold'), command=adicionar).pack(side='left', padx=8)
    tk.Button(btns, text='Adicionar certificado ao lote', bg=GREEN, fg='black', font=(FONT, 12, 'bold'), command=adicionar_certificado_lote_selecionado).pack(side='left', padx=8)
    animar_botoes_do_frame(btns)


def abrir_formulario_certificado(lote_fixo=None):
    lotes_certificados = {cert[1] for cert in state['certificados'] if cert[1] not in ['Sem lote', 'Sem lote cadastrado']}
    lotes_disponiveis = [l[0] for l in state['lotes'] if l[4] != 'Certificado' and l[0] not in lotes_certificados]

    if lote_fixo:
        lotes_disponiveis = [lote_fixo]
    elif 'Sem lote' not in lotes_disponiveis:
        lotes_disponiveis.append('Sem lote')

    campos = [
        {'nome':'certificado','label':'Código do certificado','valor':f'CERT-H2V-{datetime.now().year}-{random.randint(1000,9999)}'},
        {'nome':'lote','label':'Lote','opcoes':lotes_disponiveis,'valor':lotes_disponiveis[0]},
        {'nome':'status','label':'Status','opcoes':['Válido','Pendente','Expirado'],'valor':'Válido'},
        {'nome':'validacao','label':'Validação','opcoes':['Assinatura Digital OK','Sem Assinatura'],'valor':'Assinatura Digital OK'}]

    def salvar(dados):
        if not dados['certificado']:
            messagebox.showwarning('Campo obrigatório','Digite o código do certificado.'); return
        salvar_certificado_no_banco(dados['certificado'], dados['lote'], dados['status'], dados['validacao'])
        try:
            registrar_auditoria('Certificado criado', f"Certificado {dados['certificado']} vinculado ao lote {dados['lote']}")
        except Exception:
            pass
        if dados['lote'] not in ['Sem lote', 'Sem lote cadastrado']:
            atualizar_status_certificado_lote_no_banco(dados['lote'], 'Certificado')
        carregar_certificados(); carregar_lotes(); show_certificados()

    criar_janela_cadastro('Adicionar certificado', campos, salvar)


def show_certificados():
    set_screen('Certificados'); clear_main(); make_header('CERTIFICADOS', 'Validação digital dos lotes de hidrogênio verde')
    body = panel(ui_utils.main, 'CERTIFICADOS EMITIDOS'); body.pack(fill='x', padx=20, pady=6)
    tree = table(body, ['Certificado', 'Lote', 'Status', 'Validação'], state['certificados'])

    def adicionar():
        abrir_formulario_certificado()

    def assinar_certificado():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum certificado selecionado','Selecione um certificado para assinar.'); return
        valores = tree.item(selecionado[0], 'values')
        certificado, lote, status, validacao = valores
        if validacao == 'Assinatura Digital OK':
            messagebox.showinfo('Já assinado','Esse certificado já possui assinatura digital.'); return
        if messagebox.askyesno('Assinar certificado', f'Deseja assinar digitalmente o certificado {certificado}?'):
            atualizar_validacao_certificado_no_banco(certificado, lote, 'Assinatura Digital OK', 'Válido')
            try:
                registrar_auditoria('Certificado assinado', f'Certificado {certificado} recebeu assinatura digital demo {assinatura_demo(certificado, lote)}')
            except Exception:
                pass
            carregar_certificados(); show_certificados()

    def deletar_certificado():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum certificado selecionado','Selecione um certificado para deletar.'); return
        valores = tree.item(selecionado[0], 'values')
        certificado, lote = valores[0], valores[1]
        if messagebox.askyesno('Confirmar exclusão', f'Deseja deletar o certificado {certificado}?'):
            deletar_certificado_do_banco(certificado, lote)
            try:
                registrar_auditoria('Certificado deletado', f'Certificado {certificado} removido; lote {lote} voltou para pendente')
            except Exception:
                pass
            carregar_certificados(); carregar_lotes(); show_certificados()

    def adicionar_lote_ao_certificado():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum certificado selecionado','Selecione um certificado sem lote.'); return
        valores = tree.item(selecionado[0], 'values')
        certificado, lote_atual = valores[0], valores[1]
        if lote_atual not in ['Sem lote', 'Sem lote cadastrado', '']:
            messagebox.showwarning('Certificado já possui lote','Esse certificado já está vinculado a um lote.'); return

        lotes_certificados = {cert[1] for cert in state['certificados'] if cert[1] not in ['Sem lote', 'Sem lote cadastrado', '']}
        lotes_disponiveis = [l[0] for l in state['lotes'] if l[4] != 'Certificado' and l[0] not in lotes_certificados]
        if not lotes_disponiveis:
            messagebox.showwarning('Sem lotes disponíveis','Não existem lotes pendentes para vincular.'); return

        campos = [{'nome':'lote','label':'Lote disponível','opcoes':lotes_disponiveis,'valor':lotes_disponiveis[0]}]
        def salvar(dados):
            vincular_lote_ao_certificado_no_banco(certificado, lote_atual, dados['lote'])
            try:
                registrar_auditoria('Lote vinculado', f"Lote {dados['lote']} vinculado ao certificado {certificado}")
            except Exception:
                pass
            carregar_certificados(); carregar_lotes(); show_certificados()
        criar_janela_cadastro('Adicionar lote ao certificado', campos, salvar)

    def gerar_qr_certificado():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum certificado selecionado','Selecione um certificado para gerar QR Code.'); return
        certificado, lote, status, validacao = tree.item(selecionado[0], 'values')
        conteudo = f'H2V-TRACE | Certificado: {certificado} | Lote: {lote} | Status: {status} | Validação: {validacao} | Assinatura demo: {assinatura_demo(certificado, lote)}'
        abrir_qr_visual('QR Code do certificado', conteudo)

    def exportar_certificado_txt():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum certificado selecionado','Selecione um certificado para exportar.'); return
        certificado, lote, status, validacao = tree.item(selecionado[0], 'values')
        conteudo = f'''H2V-TRACE - CERTIFICADO DIGITAL DEMONSTRATIVO

Certificado: {certificado}
Lote vinculado: {lote}
Status: {status}
Validação: {validacao}
Assinatura demo: {assinatura_demo(certificado, lote)}
Emitido em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

Observação: arquivo demonstrativo para apresentação do MVP.
'''
        exportar_texto_padrao(f'{certificado}.txt', conteudo)

    btns = tk.Frame(ui_utils.main, bg=BG); btns.pack(pady=10)
    tk.Button(btns, text='Adicionar certificado', bg=BLUE, fg='white', font=(FONT,12,'bold'), command=adicionar).pack(side='left', padx=6)
    tk.Button(btns, text='Assinar sem assinatura', bg=GREEN, fg='black', font=(FONT,12,'bold'), command=assinar_certificado).pack(side='left', padx=6)
    tk.Button(btns, text='Vincular lote', bg=YELLOW, fg='black', font=(FONT,12,'bold'), command=adicionar_lote_ao_certificado).pack(side='left', padx=6)
    tk.Button(btns, text='QR Code', bg=PURPLE, fg='white', font=(FONT,12,'bold'), command=gerar_qr_certificado).pack(side='left', padx=6)
    tk.Button(btns, text='Exportar certificado', bg=CARD3, fg='white', font=(FONT,12,'bold'), command=exportar_certificado_txt).pack(side='left', padx=6)
    tk.Button(btns, text='Deletar', bg=RED, fg='white', font=(FONT,12,'bold'), command=deletar_certificado).pack(side='left', padx=6)
    animar_botoes_do_frame(btns)

def show_relatorios():
    set_screen('Relatórios'); clear_main(); make_header('RELATÓRIOS ESG', 'Indicadores ambientais, sociais, auditoria e rastreabilidade')
    top = tk.Frame(ui_utils.main, bg=BG); top.pack(fill='x', padx=20)
    certificados_assinados = len([c for c in state['certificados'] if c[3] == 'Assinatura Digital OK'])
    risco_medio = 0
    if state['equipment']:
        risco_medio = int(sum(calcular_risco_equipamento(e)[0] for e in state['equipment']) / len(state['equipment']))
    for title, value, sub in [('CO₂ evitado no mês', f'{len(state["lotes"]) * 12} t', 'Calculado pelos lotes'), ('Lotes auditáveis', f'{len(state["lotes"])}', 'Registros salvos'), ('Certificados assinados', str(certificados_assinados), 'Assinatura digital demo'), ('Risco médio IA', f'{risco_medio}%', 'Equipamentos')]:
        c, _ = card(top, title, value, sub); c.pack(side='left', expand=True, fill='both', padx=4, pady=3)

    body = panel(ui_utils.main, 'RESUMO DE RELATÓRIOS'); body.pack(fill='x', padx=20, pady=6)
    table(body, ['Relatório', 'Período', 'Status', 'Responsável'], state['relatorios'])

    audit_body = panel(ui_utils.main, 'LOG DE AUDITORIA - ÚLTIMAS AÇÕES'); audit_body.pack(fill='both', expand=True, padx=20, pady=6)
    table(audit_body, ['Data/Hora', 'Usuário', 'Ação', 'Detalhe'], state.get('auditoria', []))

    def adicionar():
        campos = [{'nome':'relatorio','label':'Nome do relatório','opcoes':['ESG Diário','Pegada de Carbono','Energia Renovável','Rastreabilidade','Auditoria'],'valor':'ESG Diário'}, {'nome':'periodo','label':'Período','valor':datetime.now().strftime('%d/%m/%Y')}, {'nome':'status','label':'Status','opcoes':['Gerado','Em análise','Pendente'],'valor':'Gerado'}, {'nome':'responsavel','label':'Responsável','valor':'ADM'}]
        def salvar(dados):
            salvar_relatorio_no_banco(dados['relatorio'], dados['periodo'], dados['status'], dados['responsavel'])
            try:
                registrar_auditoria('Relatório criado', f"Relatório {dados['relatorio']} do período {dados['periodo']}")
            except Exception:
                pass
            carregar_relatorios(); show_relatorios()
        criar_janela_cadastro('Adicionar relatório', campos, salvar)

    def gerar_relatorio_esg_txt():
        linhas_equipamentos = []
        for e in state['equipment']:
            risco, nivel, motivo = calcular_risco_equipamento(e)
            linhas_equipamentos.append(f'- {e[0]} | Status: {e[1]} | Risco IA: {risco}% ({nivel}) | Motivo: {motivo}')
        equipamentos_txt = chr(10).join(linhas_equipamentos) if linhas_equipamentos else '- Nenhum equipamento cadastrado.'
        conteudo = f'''H2V-TRACE - RELATÓRIO ESG AUTOMÁTICO

Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
Responsável: ADM

INDICADORES
- Lotes cadastrados: {len(state['lotes'])}
- Certificados emitidos: {len(state['certificados'])}
- Certificados assinados: {certificados_assinados}
- CO₂ evitado estimado no mês: {len(state['lotes']) * 12} t
- Equipamentos monitorados: {len(state['equipment'])}
- Risco médio IA: {risco_medio}%

EQUIPAMENTOS E IA PREDITIVA
{equipamentos_txt}

RASTREABILIDADE
- Sistema possui lotes com data/hora automática e peso fixo em kg.
- Certificados podem gerar QR Code demonstrativo e assinatura digital demo.
- Log de auditoria registra ações importantes do operador.
'''
        exportar_texto_padrao('relatorio_esg_h2v_trace.txt', conteudo)
        try:
            registrar_auditoria('Relatório ESG exportado', 'Arquivo TXT de relatório ESG automático gerado')
        except Exception:
            pass
        carregar_auditoria(); show_relatorios()

    btns = tk.Frame(ui_utils.main, bg=BG); btns.pack(pady=6)
    tk.Button(btns, text='Adicionar relatório', bg=BLUE, fg='white', font=(FONT,12,'bold'), command=adicionar).pack(side='left', padx=8)
    tk.Button(btns, text='Gerar relatório ESG automático', bg=GREEN, fg='black', font=(FONT,12,'bold'), command=gerar_relatorio_esg_txt).pack(side='left', padx=8)
    animar_botoes_do_frame(btns)

def show_alertas():
    set_screen('Alertas'); clear_main(); make_header('ALERTAS', 'Central de eventos, riscos e ocorrências da estação')
    body = panel(ui_utils.main, 'ALERTAS REGISTRADOS'); body.pack(fill='x', padx=20, pady=6)
    tree = table(body, ['Nível', 'Título', 'Descrição', 'Hora'], state['alerts'])
    def novo_alerta_manual():
        campos = [{'nome':'nivel','label':'Nível','opcoes':['Baixo','Médio','Alto','Crítico'],'valor':'Médio'}, {'nome':'titulo','label':'Título','valor':'Alerta manual'}, {'nome':'descricao','label':'Descrição','valor':'Ocorrência registrada pelo operador.'}, {'nome':'hora','label':'Hora','valor':datetime.now().strftime('%H:%M')}]
        def salvar(dados):
            if not dados['titulo']:
                messagebox.showwarning('Campo obrigatório','Digite o título do alerta.'); return
            salvar_alerta_no_banco(dados['nivel'], dados['titulo'], dados['descricao'] or 'Sem descrição.', dados['hora'] or datetime.now().strftime('%H:%M'), 'Manual'); carregar_alertas(); show_alertas()
        criar_janela_cadastro('Adicionar alerta manual', campos, salvar)
    def verificar_risco_agora():
        gerou = False
        for item in state['equipment']:
            nome, status, carga, temperatura, _ = item
            temp_num = int(''.join(ch for ch in temperatura if ch.isdigit()) or 0)
            carga_num = int(''.join(ch for ch in carga if ch.isdigit()) or 0)
            if status in ['Atenção','Manutenção','Offline']:
                gerar_alerta_automatico('Alto', f'Risco em {nome}', f'Equipamento está com status {status}.'); gerou = True
            if temp_num >= 50:
                gerar_alerta_automatico('Alto', f'Temperatura alta em {nome}', f'Equipamento registrou {temperatura}.'); gerou = True
            if carga_num < 70:
                gerar_alerta_automatico('Médio', f'Carga baixa em {nome}', f'Carga atual: {carga}.'); gerou = True
        carregar_alertas(); show_alertas()
        messagebox.showwarning('Verificação concluída','Foram encontrados riscos e alertas automáticos foram gerados.') if gerou else messagebox.showinfo('Verificação concluída','Nenhuma condição perigosa encontrada agora.')
    def deletar():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum alerta selecionado','Selecione um alerta para deletar.'); return
        valores = tree.item(selecionado[0], 'values')
        if messagebox.askyesno('Confirmar exclusão', f'Deseja deletar o alerta "{valores[1]}"?'):
            deletar_alerta_do_banco(valores[0], valores[1], valores[2], valores[3]); carregar_alertas(); show_alertas()
    def limpar():
        if messagebox.askyesno('Limpar alertas','Deseja apagar todos os alertas salvos?'):
            limpar_alertas_do_banco(); carregar_alertas(); show_alertas()
    btns = tk.Frame(ui_utils.main, bg=BG); btns.pack(pady=10)
    for text,bg,fg,cmd in [('Adicionar alerta manual',BLUE,'white',novo_alerta_manual), ('Verificar risco automático',YELLOW,'black',verificar_risco_agora), ('Deletar alerta',RED,'white',deletar), ('Limpar alertas',GREEN,'black',limpar)]:
        tk.Button(btns, text=text, bg=bg, fg=fg, font=(FONT,12,'bold'), command=cmd).pack(side='left', padx=8)
    animar_botoes_do_frame(btns)



def show_auditoria():
    set_screen('Auditoria')
    clear_main()
    make_header('AUDITORIA', 'Histórico de ações importantes do sistema')

    try:
        carregar_auditoria()
    except Exception:
        state['auditoria'] = []

    body = panel(ui_utils.main, 'LOG DE AUDITORIA')
    body.pack(fill='x', padx=20, pady=6)

    if not state.get('auditoria'):
        tk.Label(
            body,
            text='Nenhuma ação registrada ainda.',
            fg=GRAY,
            bg=CARD,
            font=(FONT, 13)
        ).pack(anchor='w', padx=20, pady=20)
    else:
        table(body, ['Data/Hora', 'Usuário', 'Ação', 'Detalhe'], state['auditoria'])

    btns = tk.Frame(ui_utils.main, bg=BG)
    btns.pack(pady=8)

    def atualizar_log():
        carregar_auditoria()
        show_auditoria()

    tk.Button(
        btns,
        text='Atualizar auditoria',
        bg=BLUE,
        fg='white',
        font=(FONT, 12, 'bold'),
        command=atualizar_log
    ).pack(side='left', padx=8)

    animar_botoes_do_frame(btns)

def show_configuracoes():
    set_screen('Configurações'); clear_main(); make_header('CONFIGURAÇÕES', 'Parâmetros operacionais da estação de controle')
    body = panel(ui_utils.main, 'CONFIGURAÇÕES DO SISTEMA'); body.pack(fill='x', padx=20, pady=6)
    campos = {}; opcoes_sincronizacao = ['A cada 5 min','A cada 10 min','A cada 30 min','A cada 1h','A cada 2h','A cada 4h']
    validar_positivo = ui_utils.root.register(lambda valor: valor == '' or valor.isdigit())
    validar_temp = ui_utils.root.register(lambda valor: valor in ['', '-'] or (valor[1:].isdigit() if valor.startswith('-') else valor.isdigit()))
    for key, value in state['settings'].items():
        row = tk.Frame(body, bg=CARD2); row.pack(fill='x', padx=14, pady=4)
        tk.Label(row, text=key.replace('_',' ').title(), fg='white', bg=CARD2, font=(FONT,12), width=25, anchor='w').pack(side='left', padx=10, pady=10)
        if key == 'modo_operacao':
            combo = ttk.Combobox(row, values=['Automático','Manual'], state='readonly', font=(FONT,12)); combo.set(value if value in ['Automático','Manual'] else 'Automático'); combo.pack(side='left', fill='x', expand=True, padx=10); campos[key] = combo
        elif key == 'backup':
            combo = ttk.Combobox(row, values=['Ativado','Desativado'], state='readonly', font=(FONT,12)); combo.set(value if value in ['Ativado','Desativado'] else 'Ativado'); combo.pack(side='left', fill='x', expand=True, padx=10); campos[key] = combo
        elif key == 'sincronizacao':
            combo = ttk.Combobox(row, values=opcoes_sincronizacao, state='readonly', font=(FONT,12)); combo.set(value if value in opcoes_sincronizacao else 'A cada 5 min'); combo.pack(side='left', fill='x', expand=True, padx=10); campos[key] = combo
        elif key == 'limite_temp':
            temp_frame = tk.Frame(row, bg=CARD2); temp_frame.pack(side='left', fill='x', expand=True, padx=10)
            numero = value.replace('°C','').replace('°','').replace('C','').strip() or '0'
            entrada = make_entry(temp_frame, validate='key', validatecommand=(validar_temp, '%P')); entrada.insert(0, numero); entrada.pack(side='left', fill='x', expand=True)
            tk.Label(temp_frame, text=' °C', fg='white', bg=CARD2, font=(FONT,12,'bold')).pack(side='left', padx=(6,0)); campos[key] = entrada
        elif key == 'meta_diaria':
            kg_frame = tk.Frame(row, bg=CARD2); kg_frame.pack(side='left', fill='x', expand=True, padx=10)
            numero = ''.join(ch for ch in value if ch.isdigit()) or '0'
            entrada = make_entry(kg_frame, validate='key', validatecommand=(validar_positivo, '%P')); entrada.insert(0, numero); entrada.pack(side='left', fill='x', expand=True)
            tk.Label(kg_frame, text=' kg', fg='white', bg=CARD2, font=(FONT,12,'bold')).pack(side='left', padx=(6,0)); campos[key] = entrada
        else:
            entrada = make_entry(row); entrada.insert(0, value); entrada.pack(side='left', fill='x', expand=True, padx=10); campos[key] = entrada
    def salvar():
        for key, campo in campos.items():
            valor = campo.get().strip()
            if key == 'limite_temp': state['settings'][key] = f'{valor if valor not in ["", "-"] else "0"} °C'
            elif key == 'meta_diaria': state['settings'][key] = f'{valor or "0"} kg'
            elif key == 'sincronizacao': state['settings'][key] = valor if valor in opcoes_sincronizacao else 'A cada 5 min'
            else: state['settings'][key] = valor
        salvar_configuracoes_no_banco(); messagebox.showinfo('Configurações salvas', 'Configurações salvas no banco de dados com sucesso.')
    btn = tk.Button(ui_utils.main, text='Salvar configurações', bg=GREEN, fg='black', font=(FONT,12,'bold'), command=salvar); btn.pack(pady=6); animar_botao(btn, GREEN, CARD3)


def show_usuarios():
    set_screen('Usuários'); clear_main(); make_header('USUÁRIOS', 'Controle de acesso e operadores conectados')
    body = panel(ui_utils.main, 'USUÁRIOS CADASTRADOS'); body.pack(fill='x', padx=20, pady=6)
    tree = table(body, ['Usuário', 'Perfil', 'Status', 'Permissão'], state['users'])
    perfis = ['Administrador', 'Operador', 'Manutenção', 'Auditor']; permissoes = ['Acesso total', 'Produção', 'Equipamentos', 'Relatórios', 'Somente leitura']
    def adicionar():
        campos = [{'nome':'nome','label':'Nome do usuário','valor':''}, {'nome':'perfil','label':'Perfil','opcoes':perfis,'valor':'Operador'}, {'nome':'permissao','label':'Permissão','opcoes':permissoes,'valor':'Produção'}]
        def salvar(dados):
            nome = dados['nome'].strip()
            if not nome:
                messagebox.showwarning('Campo obrigatório','Digite o nome do usuário.'); return
            if any(usuario[0].lower() == nome.lower() for usuario in state['users']):
                messagebox.showwarning('Usuário já existe','Já existe um usuário com esse nome.'); return
            salvar_usuario_no_banco(nome, dados['perfil'], 'Online', dados['permissao']); carregar_usuarios(); show_usuarios()
        criar_janela_cadastro('Novo usuário', campos, salvar)
    def deletar():
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showwarning('Nenhum usuário selecionado','Selecione um usuário na tabela para deletar.'); return
        valores = tree.item(selecionado[0], 'values'); nome = valores[0]
        if nome == 'ADM':
            messagebox.showwarning('Ação bloqueada','O usuário ADM principal não pode ser deletado.'); return
        if messagebox.askyesno('Confirmar exclusão', f'Deseja deletar o usuário {nome}?'):
            deletar_usuario_do_banco(nome); carregar_usuarios(); show_usuarios()
    btns = tk.Frame(ui_utils.main, bg=BG); btns.pack(pady=10)
    tk.Button(btns, text='Adicionar usuário', bg=BLUE, fg='white', font=(FONT,12,'bold'), command=adicionar).pack(side='left', padx=8)
    tk.Button(btns, text='Deletar usuário selecionado', bg=RED, fg='white', font=(FONT,12,'bold'), command=deletar).pack(side='left', padx=8)
    animar_botoes_do_frame(btns)
