# db.py
import sqlite3
import time
from datetime import datetime
from constants import DB_FILE
from state import state, alertas_automaticos_cache


def _conn():
    return sqlite3.connect(DB_FILE)


def init_database():
    conn = _conn()
    cursor = conn.cursor()
    cursor.execute('PRAGMA journal_mode=WAL')
    cursor.execute('PRAGMA synchronous=NORMAL')

    cursor.execute('CREATE TABLE IF NOT EXISTS configuracoes (chave TEXT PRIMARY KEY, valor TEXT NOT NULL)')
    cursor.execute('''CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE,
        perfil TEXT NOT NULL, status TEXT NOT NULL, permissao TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS equipamentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, status TEXT NOT NULL,
        carga TEXT NOT NULL, temperatura TEXT NOT NULL, observacao TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS lotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, lote TEXT NOT NULL UNIQUE, inicio TEXT NOT NULL,
        quantidade TEXT NOT NULL, origem_energia TEXT NOT NULL, certificado TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS certificados (
        id INTEGER PRIMARY KEY AUTOINCREMENT, certificado TEXT NOT NULL UNIQUE, lote TEXT NOT NULL,
        status TEXT NOT NULL, validacao TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS relatorios (
        id INTEGER PRIMARY KEY AUTOINCREMENT, relatorio TEXT NOT NULL, periodo TEXT NOT NULL,
        status TEXT NOT NULL, responsavel TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS alertas (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nivel TEXT NOT NULL, titulo TEXT NOT NULL,
        descricao TEXT NOT NULL, hora TEXT NOT NULL, origem TEXT NOT NULL)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS auditoria (
        id INTEGER PRIMARY KEY AUTOINCREMENT, data_hora TEXT NOT NULL, usuario TEXT NOT NULL,
        acao TEXT NOT NULL, detalhe TEXT NOT NULL)''')

    for usuario in state['users']:
        cursor.execute('INSERT OR IGNORE INTO usuarios (nome, perfil, status, permissao) VALUES (?, ?, ?, ?)', tuple(usuario))

    for chave, valor in state['settings'].items():
        cursor.execute('INSERT OR IGNORE INTO configuracoes (chave, valor) VALUES (?, ?)', (chave, valor))

    conn.commit()
    conn.close()


def carregar_configuracoes():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT chave, valor FROM configuracoes')
    for chave, valor in cursor.fetchall():
        if chave in state['settings']:
            state['settings'][chave] = valor
    conn.close()

    if state['settings'].get('modo_operacao') in ['Ativado', 'Desativado']:
        state['settings']['modo_operacao'] = 'Automático'


def salvar_configuracoes_no_banco():
    conn = _conn(); cursor = conn.cursor()
    for chave, valor in state['settings'].items():
        cursor.execute('''INSERT INTO configuracoes (chave, valor) VALUES (?, ?)
            ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor''', (chave, valor))
    conn.commit(); conn.close()


def carregar_usuarios():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT nome, perfil, status, permissao FROM usuarios ORDER BY id')
    dados = cursor.fetchall(); conn.close()
    if dados:
        state['users'] = [list(usuario) for usuario in dados]


def salvar_usuario_no_banco(nome, perfil, status, permissao):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''INSERT INTO usuarios (nome, perfil, status, permissao) VALUES (?, ?, ?, ?)
        ON CONFLICT(nome) DO UPDATE SET perfil = excluded.perfil, status = excluded.status, permissao = excluded.permissao''',
        (nome, perfil, status, permissao))
    conn.commit(); conn.close()


def deletar_usuario_do_banco(nome):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('DELETE FROM usuarios WHERE nome = ?', (nome,))
    conn.commit(); conn.close()


def carregar_equipamentos():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT nome, status, carga, temperatura, observacao FROM equipamentos ORDER BY id')
    state['equipment'] = [list(row) for row in cursor.fetchall()]
    conn.close()


def salvar_equipamento_no_banco(nome, status, carga, temperatura, observacao):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('INSERT INTO equipamentos (nome, status, carga, temperatura, observacao) VALUES (?, ?, ?, ?, ?)',
                   (nome, status, carga, temperatura, observacao))
    conn.commit(); conn.close()


def deletar_equipamento_do_banco(nome, observacao):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('DELETE FROM equipamentos WHERE id = (SELECT id FROM equipamentos WHERE nome = ? AND observacao = ? LIMIT 1)', (nome, observacao))
    conn.commit(); conn.close()


def atualizar_status_equipamento_no_banco(nome, observacao, novo_status):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''UPDATE equipamentos SET status = ? WHERE id = (
        SELECT id FROM equipamentos WHERE nome = ? AND observacao = ? LIMIT 1)''', (novo_status, nome, observacao))
    conn.commit(); conn.close()


def carregar_lotes():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT lote, inicio, quantidade, origem_energia, certificado FROM lotes ORDER BY id')
    state['lotes'] = [list(row) for row in cursor.fetchall()]
    conn.close()


def salvar_lote_no_banco(lote, inicio, quantidade, origem_energia, certificado):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''INSERT INTO lotes (lote, inicio, quantidade, origem_energia, certificado) VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(lote) DO UPDATE SET inicio = excluded.inicio, quantidade = excluded.quantidade,
        origem_energia = excluded.origem_energia, certificado = excluded.certificado''',
        (lote, inicio, quantidade, origem_energia, certificado))
    conn.commit(); conn.close()


def carregar_certificados():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT certificado, lote, status, validacao FROM certificados ORDER BY id')
    state['certificados'] = [list(row) for row in cursor.fetchall()]
    conn.close()


def salvar_certificado_no_banco(certificado, lote, status, validacao):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''INSERT INTO certificados (certificado, lote, status, validacao) VALUES (?, ?, ?, ?)
        ON CONFLICT(certificado) DO UPDATE SET lote = excluded.lote, status = excluded.status, validacao = excluded.validacao''',
        (certificado, lote, status, validacao))
    conn.commit(); conn.close()



def atualizar_validacao_certificado_no_banco(certificado, lote, nova_validacao, novo_status=None):
    conn = _conn(); cursor = conn.cursor()
    if novo_status:
        cursor.execute("""UPDATE certificados SET validacao = ?, status = ? WHERE id = (
            SELECT id FROM certificados WHERE certificado = ? AND lote = ? LIMIT 1)""",
            (nova_validacao, novo_status, certificado, lote))
    else:
        cursor.execute("""UPDATE certificados SET validacao = ? WHERE id = (
            SELECT id FROM certificados WHERE certificado = ? AND lote = ? LIMIT 1)""",
            (nova_validacao, certificado, lote))
    conn.commit(); conn.close()


def atualizar_status_certificado_lote_no_banco(lote, status_certificado):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('UPDATE lotes SET certificado = ? WHERE lote = ?', (status_certificado, lote))
    conn.commit(); conn.close()



def deletar_certificado_do_banco(certificado, lote):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''DELETE FROM certificados WHERE id = (
        SELECT id FROM certificados WHERE certificado = ? AND lote = ? LIMIT 1)''',
        (certificado, lote))
    if lote and lote not in ['Sem lote', 'Sem lote cadastrado']:
        cursor.execute('UPDATE lotes SET certificado = ? WHERE lote = ?', ('Pendente', lote))
    conn.commit(); conn.close()


def vincular_lote_ao_certificado_no_banco(certificado, lote_antigo, novo_lote):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''UPDATE certificados SET lote = ?, status = ? WHERE id = (
        SELECT id FROM certificados WHERE certificado = ? AND lote = ? LIMIT 1)''',
        (novo_lote, 'Válido', certificado, lote_antigo))
    cursor.execute('UPDATE lotes SET certificado = ? WHERE lote = ?', ('Certificado', novo_lote))
    conn.commit(); conn.close()


def registrar_auditoria(acao, detalhe, usuario='ADM'):
    conn = _conn(); cursor = conn.cursor()
    data_hora = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
    cursor.execute('INSERT INTO auditoria (data_hora, usuario, acao, detalhe) VALUES (?, ?, ?, ?)',
                   (data_hora, usuario, acao, detalhe))
    conn.commit(); conn.close()
    carregar_auditoria()


def carregar_auditoria():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT data_hora, usuario, acao, detalhe FROM auditoria ORDER BY id DESC LIMIT 80')
    state['auditoria'] = [list(row) for row in cursor.fetchall()]
    conn.close()

def carregar_relatorios():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT relatorio, periodo, status, responsavel FROM relatorios ORDER BY id')
    state['relatorios'] = [list(row) for row in cursor.fetchall()]
    conn.close()


def salvar_relatorio_no_banco(relatorio, periodo, status, responsavel):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('INSERT INTO relatorios (relatorio, periodo, status, responsavel) VALUES (?, ?, ?, ?)',
                   (relatorio, periodo, status, responsavel))
    conn.commit(); conn.close()


def carregar_alertas():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('SELECT nivel, titulo, descricao, hora FROM alertas ORDER BY id DESC')
    state['alerts'] = [list(row) for row in cursor.fetchall()]
    conn.close()


def salvar_alerta_no_banco(nivel, titulo, descricao, hora, origem='Manual'):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('INSERT INTO alertas (nivel, titulo, descricao, hora, origem) VALUES (?, ?, ?, ?, ?)',
                   (nivel, titulo, descricao, hora, origem))
    conn.commit(); conn.close()


def deletar_alerta_do_banco(nivel, titulo, descricao, hora):
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('''DELETE FROM alertas WHERE id = (
        SELECT id FROM alertas WHERE nivel = ? AND titulo = ? AND descricao = ? AND hora = ? LIMIT 1)''',
        (nivel, titulo, descricao, hora))
    conn.commit(); conn.close()


def limpar_alertas_do_banco():
    conn = _conn(); cursor = conn.cursor()
    cursor.execute('DELETE FROM alertas')
    conn.commit(); conn.close()


def gerar_alerta_automatico(nivel, titulo, descricao):
    agora = time.time()
    ultima_vez = alertas_automaticos_cache.get(titulo, 0)
    if agora - ultima_vez < 300:
        return
    alertas_automaticos_cache[titulo] = agora
    hora = datetime.now().strftime('%H:%M')
    salvar_alerta_no_banco(nivel, titulo, descricao, hora, 'Automático')
    carregar_alertas()
