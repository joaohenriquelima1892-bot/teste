# state.py
import random

state = {
    'production': 120.5,
    'daily': 2892,
    'efficiency': 91,
    'energy': 4.28,
    'emission': 5.62,
    'chart_values': [random.randint(70, 140) for _ in range(30)],
    'users': [['ADM', 'Administrador', 'Online', 'Acesso total']],
    'alerts': [],
    'equipment': [],
    'lotes': [],
    'certificados': [],
    'relatorios': [],
    'auditoria': [],
    'settings': {
        'modo_operacao': 'Automático',
        'meta_diaria': '3500 kg',
        'limite_temp': '50 °C',
        'backup': 'Ativado',
        'sincronizacao': 'A cada 5 min'
    }
}

alertas_automaticos_cache = {}
active_menu_name = 'Dashboard'
current_screen = None
temperatura_cache = '26°C'
ultima_busca_temperatura = 0
