# app.py
import tkinter as tk
from datetime import datetime
import time

from constants import *
import state as app_state
from db import (
    init_database, carregar_configuracoes, carregar_usuarios, carregar_equipamentos,
    carregar_lotes, carregar_certificados, carregar_relatorios, carregar_alertas, carregar_auditoria
)
from ui_utils import aplicar_estilo_global, setup_ui_refs, animar_bg, animar_entrada_tela
import ui_utils
import screens

root = tk.Tk()
root.title('H2V-TRACE - Estação de Controle')
root.state('zoomed')
root.configure(bg=BG)

aplicar_estilo_global()

sidebar = tk.Frame(root, bg=SIDEBAR, width=270)
sidebar.pack(side='left', fill='y')

logo = tk.Label(sidebar, text='♧ H2V-TRACE', fg=GREEN, bg=SIDEBAR, font=(FONT_BOLD, 24, 'bold'))
logo.pack(pady=(25, 0))

tk.Label(
    sidebar,
    text='PLATAFORMA INTELIGENTE PARA\nHIDROGÊNIO VERDE',
    fg='white',
    bg=SIDEBAR,
    font=(FONT, 9)
).pack(pady=(0, 25))

main = tk.Frame(root, bg=BG)
main.pack(side='left', fill='both', expand=True, padx=2, pady=2)
setup_ui_refs(root, main)


def ativar_menu(nome_ativo):
    app_state.active_menu_name = nome_ativo
    for nome, botao in ui_utils.menu_buttons.items():
        ativo = nome == nome_ativo
        botao.configure(
            bg=CARD2 if ativo else SIDEBAR,
            fg=GREEN if ativo else TEXT,
            text=('▌  ' if ativo else '   ') + nome
        )


def trocar_tela(nome, command):
    ativar_menu(nome)
    for widget in main.winfo_children():
        try:
            animar_bg(widget, CARD, SHADOW, passos=4, delay=8)
        except Exception:
            pass
    root.after(80, command)
    root.after(140, animar_entrada_tela)


def comando_menu(nome, command):
    def executar():
        trocar_tela(nome, command)
    return executar


menu = [
    ('Dashboard', screens.show_dashboard),
    ('Produção', screens.show_producao),
    ('Energia', screens.show_energia),
    ('Equipamentos', screens.show_equipamentos),
    ('Lotes e Rastreabilidade', screens.show_lotes),
    ('Certificados', screens.show_certificados),
    ('Relatórios ESG', screens.show_relatorios),
    ('Alertas', screens.show_alertas),
    ('Auditoria', screens.show_auditoria),
    ('Configurações', screens.show_configuracoes),
    ('Usuários', screens.show_usuarios)
]

for name, command in menu:
    btn = tk.Button(
        sidebar,
        text='   ' + name,
        anchor='w',
        fg=TEXT,
        bg=SIDEBAR,
        activebackground=CARD2,
        activeforeground=GREEN,
        bd=0,
        cursor='hand2',
        font=(FONT_BOLD, 12),
        padx=18,
        pady=9,
        width=25,
        command=comando_menu(name, command)
    )
    btn.pack(pady=3, padx=12, fill='x')

    def menu_enter(event, b=btn, n=name):
        if n != app_state.active_menu_name:
            animar_bg(b, SIDEBAR, CARD2)

    def menu_leave(event, b=btn, n=name):
        if n != app_state.active_menu_name:
            animar_bg(b, CARD2, SIDEBAR)

    btn.bind('<Enter>', menu_enter)
    btn.bind('<Leave>', menu_leave)
    ui_utils.menu_buttons[name] = btn

ativar_menu('Dashboard')

status_frame = tk.Frame(sidebar, bg=CARD)
status_frame.pack(side='bottom', fill='x', padx=15, pady=25)

tk.Label(
    status_frame,
    text='● Sistema Online\n\nTodos os sistemas operando\nnormalmente.',
    fg=GREEN,
    bg=CARD,
    justify='left',
    font=(FONT, 12)
).pack(padx=20, pady=20)


def update_clock():
    agora_timestamp = time.time()

    if agora_timestamp - app_state.ultima_busca_temperatura > 600:
        app_state.ultima_busca_temperatura = agora_timestamp
        try:
            import requests
            resposta = requests.get('https://wttr.in/Teresina?format=%t', timeout=2)
            if resposta.status_code == 200 and resposta.text.strip():
                app_state.temperatura_cache = resposta.text.strip()
        except Exception:
            pass

    if ui_utils.clock_label:
        data = datetime.now().strftime('%d/%m/%Y')
        hora = datetime.now().strftime('%H:%M:%S')
        ui_utils.clock_label.config(text=f'☀ {app_state.temperatura_cache}   📅 {data}   🕒 {hora}')

    root.after(1000, update_clock)


def iniciar_app():
    init_database()
    carregar_configuracoes()
    carregar_usuarios()
    carregar_equipamentos()
    carregar_lotes()
    carregar_certificados()
    carregar_relatorios()
    carregar_alertas()
    carregar_auditoria()

    update_clock()
    screens.show_dashboard()
    root.after(120, animar_entrada_tela)
    root.mainloop()


if __name__ == '__main__':
    iniciar_app()
