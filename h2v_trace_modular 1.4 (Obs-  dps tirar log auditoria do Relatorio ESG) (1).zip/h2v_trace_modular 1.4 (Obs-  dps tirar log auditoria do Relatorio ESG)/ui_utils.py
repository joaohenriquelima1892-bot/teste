# ui_utils.py
import tkinter as tk
from tkinter import ttk
from constants import *

root = None
main = None
clock_label = None
menu_buttons = {}


def setup_ui_refs(root_ref, main_ref):
    global root, main
    root = root_ref
    main = main_ref


def aplicar_estilo_global():
    style = ttk.Style()
    try:
        style.theme_use('clam')
    except tk.TclError:
        pass

    style.configure('Treeview', background=CARD, foreground=TEXT, fieldbackground=CARD,
                    rowheight=34, borderwidth=0, font=(FONT, 10))
    style.configure('Treeview.Heading', background=CARD2, foreground=TEXT,
                    borderwidth=0, font=(FONT_BOLD, 10))
    style.map('Treeview', background=[('selected', BLUE)], foreground=[('selected', '#020617')])
    style.configure('TCombobox', fieldbackground=CARD2, background=CARD2, foreground=TEXT,
                    arrowcolor=TEXT, borderwidth=0, padding=6, font=(FONT, 11))
    style.configure('Vertical.TScrollbar', background=CARD2, troughcolor=CARD,
                    bordercolor=CARD, arrowcolor=TEXT, relief='flat', width=10)


def hex_to_rgb(cor):
    cor = cor.lstrip('#')
    return tuple(int(cor[i:i+2], 16) for i in (0, 2, 4))


def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % tuple(max(0, min(255, int(v))) for v in rgb)


def misturar_cores(cor1, cor2, fator):
    r1, g1, b1 = hex_to_rgb(cor1)
    r2, g2, b2 = hex_to_rgb(cor2)
    return rgb_to_hex((r1 + (r2-r1)*fator, g1 + (g2-g1)*fator, b1 + (b2-b1)*fator))


def animar_bg(widget, inicio, fim, passos=8, delay=12):
    def etapa(i=0):
        if not widget.winfo_exists():
            return
        try:
            widget.configure(bg=misturar_cores(inicio, fim, i / passos))
        except tk.TclError:
            return
        if i < passos:
            widget.after(delay, lambda: etapa(i + 1))
    etapa()


def aplicar_hover(widget, normal, hover, filhos=True):
    def entrar(_): animar_bg(widget, normal, hover)
    def sair(_): animar_bg(widget, hover, normal)
    widget.bind('<Enter>', entrar)
    widget.bind('<Leave>', sair)
    if filhos:
        for child in widget.winfo_children():
            child.bind('<Enter>', entrar)
            child.bind('<Leave>', sair)


def animar_botao(btn, normal, hover=None):
    hover = hover or CARD3
    btn.bind('<Enter>', lambda _: animar_bg(btn, normal, hover))
    btn.bind('<Leave>', lambda _: animar_bg(btn, hover, normal))
    btn.configure(cursor='hand2', relief='flat', bd=0)


def animar_botoes_do_frame(frame):
    for child in frame.winfo_children():
        if isinstance(child, tk.Button):
            try:
                animar_botao(child, child.cget('bg'), CARD3)
            except tk.TclError:
                pass


def efeito_clique(widget):
    try:
        original = widget.cget('bg')
    except tk.TclError:
        return
    animar_bg(widget, original, BLUE, passos=4, delay=10)
    widget.after(80, lambda: animar_bg(widget, BLUE, original, passos=5, delay=10))


def clear_main():
    for widget in main.winfo_children():
        widget.destroy()


def animar_entrada_tela():
    for i, widget in enumerate(main.winfo_children()):
        try:
            widget.pack_configure(pady=(14, 0))
            widget.after(30 + i * 35, lambda w=widget: w.pack_configure(pady=6))
        except tk.TclError:
            pass


def make_entry(parent, **kwargs):
    kwargs.setdefault('font', (FONT, 12))
    kwargs.setdefault('bg', '#0b1220')
    kwargs.setdefault('fg', TEXT)
    kwargs.setdefault('insertbackground', TEXT)
    kwargs.setdefault('relief', 'flat')
    kwargs.setdefault('highlightthickness', 1)
    kwargs.setdefault('highlightbackground', BORDER)
    kwargs.setdefault('highlightcolor', BLUE)
    return tk.Entry(parent, **kwargs)


def make_button(parent, text, command=None, bg=BLUE, fg='white', width=None):
    btn = tk.Button(parent, text=text, bg=bg, fg=fg, activebackground=CARD3,
                    activeforeground=fg, bd=0, relief='flat', cursor='hand2',
                    font=(FONT_BOLD, 11), padx=18, pady=10, width=width,
                    command=lambda: (efeito_clique(btn), command() if command else None))
    animar_botao(btn, bg, CARD3)
    return btn


def make_header(title, subtitle):
    global clock_label
    header = tk.Frame(main, bg=BG)
    header.pack(fill='x', padx=20, pady=8)

    left = tk.Frame(header, bg=BG); left.pack(side='left')
    right = tk.Frame(header, bg=BG); right.pack(side='right')

    tk.Label(left, text=title, fg=TEXT, bg=BG, font=(FONT_BOLD, 30, 'bold')).pack(anchor='w')
    tk.Label(left, text=subtitle, fg=GRAY, bg=BG, font=(FONT, 13)).pack(anchor='w', pady=(2, 0))
    clock_label = tk.Label(right, text='', fg=TEXT, bg=BG, font=(FONT, 15))
    clock_label.pack(side='right', padx=20)
    tk.Label(right, text='● ADM', fg=GREEN, bg=CARD2, font=(FONT_BOLD, 12), padx=20, pady=10).pack(side='right')


def card(parent, title, value, subtitle='', color=GREEN):
    shadow = tk.Frame(parent, bg=SHADOW)
    frame = tk.Frame(shadow, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
    frame.pack(fill='both', expand=True, padx=(0, 3), pady=(0, 3))
    tk.Label(frame, text=title.upper(), fg=GRAY, bg=CARD, font=(FONT_BOLD, 10)).pack(anchor='w', padx=16, pady=(14, 5))
    value_label = tk.Label(frame, text=value, fg=TEXT, bg=CARD, font=(FONT_BOLD, 27, 'bold'))
    value_label.pack(anchor='w', padx=16)
    tk.Label(frame, text=subtitle, fg=color, bg=CARD, font=(FONT, 11)).pack(anchor='w', padx=16, pady=(3, 14))
    aplicar_hover(frame, CARD, CARD2)
    return shadow, value_label


def panel(parent, title):
    # Painel simples: o conteúdo é colocado dentro do mesmo frame do título.
    # Isso evita aquele espaço vazio grande que aparecia quando o conteúdo ficava
    # fora do frame interno do painel.
    frame = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
    tk.Label(frame, text=title, fg=TEXT, bg=CARD, font=(FONT_BOLD, 14, 'bold')).pack(anchor='w', padx=16, pady=(14, 10))
    aplicar_hover(frame, CARD, '#162033')
    return frame


def table(parent, headers, rows):
    tree = ttk.Treeview(parent, columns=headers, show='headings', height=12, style='Treeview')
    tree.tag_configure('odd', background=CARD)
    tree.tag_configure('even', background='#0f172a')
    tree.tag_configure('hover', background='#1e3a5f')
    tree._last_hover = None
    for h in headers:
        tree.heading(h, text=h)
        tree.column(h, anchor='center', width=150)
    for idx, r in enumerate(rows):
        tree.insert('', 'end', values=r, tags=('even' if idx % 2 == 0 else 'odd',))

    def hover_linha(event):
        item = tree.identify_row(event.y)
        if tree._last_hover and tree.exists(tree._last_hover):
            idx = tree.index(tree._last_hover)
            tree.item(tree._last_hover, tags=('even' if idx % 2 == 0 else 'odd',))
        if item:
            tree.item(item, tags=('hover',))
            tree._last_hover = item

    def sair_tabela(_):
        if tree._last_hover and tree.exists(tree._last_hover):
            idx = tree.index(tree._last_hover)
            tree.item(tree._last_hover, tags=('even' if idx % 2 == 0 else 'odd',))
        tree._last_hover = None

    tree.bind('<Motion>', hover_linha)
    tree.bind('<Leave>', sair_tabela)
    tree.pack(fill='both', expand=True, padx=12, pady=9)
    return tree


def abrir_popup_centralizado(janela, largura=560, altura=520):
    tela_largura = janela.winfo_screenwidth()
    tela_altura = janela.winfo_screenheight()
    largura = min(largura, tela_largura - 100)
    altura = min(altura, tela_altura - 120)
    x = int((tela_largura - largura) / 2)
    y = int((tela_altura - altura) / 2)
    janela.geometry(f'{largura}x{altura}+{x}+{y}')
    janela.resizable(False, False)
    janela.lift()
    janela.focus_force()


def criar_janela_cadastro(titulo, campos, callback_salvar):
    janela = tk.Toplevel(root)
    janela.title(titulo)
    janela.configure(bg=BG)
    janela.transient(root)
    janela.grab_set()
    abrir_popup_centralizado(janela, 560, 520)

    tk.Label(janela, text=titulo.upper(), fg='white', bg=BG, font=(FONT, 18, 'bold')).pack(fill='x', pady=(16, 10))
    form = tk.Frame(janela, bg=BG)
    form.pack(fill='both', expand=True, padx=26)
    widgets = {}

    for campo in campos:
        nome = campo['nome']; label = campo['label']; valor = campo.get('valor', ''); opcoes = campo.get('opcoes')
        tk.Label(form, text=label, fg='white', bg=BG, font=(FONT, 10, 'bold'), anchor='w').pack(fill='x', pady=(5, 2))
        if opcoes:
            widget = ttk.Combobox(form, values=opcoes, state='readonly', font=(FONT, 10))
            widget.set(valor if valor else opcoes[0])
        else:
            widget = tk.Entry(form, font=(FONT, 10), bg='#101a2a', fg='white', insertbackground='white', relief='flat')
            widget.insert(0, valor)
        widget.pack(fill='x', pady=(0, 8), ipady=5)
        widgets[nome] = widget

    def salvar():
        dados = {nome: widget.get().strip() for nome, widget in widgets.items()}
        callback_salvar(dados)
        if janela.winfo_exists():
            janela.destroy()

    rodape = tk.Frame(janela, bg=SIDEBAR, height=76)
    rodape.pack(fill='x', side='bottom')
    rodape.pack_propagate(False)
    botoes = tk.Frame(rodape, bg=SIDEBAR)
    botoes.pack(expand=True)
    tk.Button(botoes, text='Salvar', bg=GREEN, fg='black', font=(FONT, 11, 'bold'), command=salvar, width=16, relief='flat', cursor='hand2').pack(side='left', padx=8, ipady=6)
    tk.Button(botoes, text='Cancelar', bg=RED, fg='white', font=(FONT, 11, 'bold'), command=janela.destroy, width=14, relief='flat', cursor='hand2').pack(side='left', padx=8, ipady=6)
    animar_botoes_do_frame(botoes)
